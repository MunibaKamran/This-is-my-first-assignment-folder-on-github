"use strict";
//2. Personal Message: Store a person’s name in a variable, and print a message to that person. Your message should be simple, such as, “Hello Eric,would you like to learn some Python today?”//
let firstName = "Eric";
console.log(`Hello ${firstName}, "would you like to learn some python today"`);
